
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

[ApiController]
[Route("[controller]")]
public class LogTestController : ControllerBase
{
    private readonly ILogger<LogTestController> _logger;

    public LogTestController(ILogger<LogTestController> logger)
    {
        _logger = logger;
    }

    [HttpGet]
    public IActionResult Get()
    {
        _logger.LogDebug("This is a Debug log.");
        _logger.LogInformation("This is an Info log.");
        _logger.LogWarning("This is a Warning log.");
        _logger.LogTrace("This is a Trace log.");
        return Ok("Logs generated.");
    }
}
